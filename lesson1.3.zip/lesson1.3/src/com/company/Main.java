package com.company;

public class Main {

    public static void main(String[] args) {
final String CONST = "Hello";
String lina = "World!";
        System.out.println(CONST +" "+lina);



    }
}
